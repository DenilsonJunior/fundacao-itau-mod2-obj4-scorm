BehaviorAdapt(1920,1080,30);
//# sourceMappingURL=resize.js.map
