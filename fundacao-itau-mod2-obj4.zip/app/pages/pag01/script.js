events.on("ready",function(){});
//# sourceMappingURL=script.js.map
